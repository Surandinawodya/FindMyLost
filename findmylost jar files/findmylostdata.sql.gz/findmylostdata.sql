-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2024 at 05:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `findmylostdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `Item Id` int(10) NOT NULL,
  `Item` varchar(50) NOT NULL,
  `Description` text NOT NULL,
  `FoundDate` date NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Location` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`Item Id`, `Item`, `Description`, `FoundDate`, `Status`, `Location`, `Email`) VALUES
(1, 'bag', 'black', '2023-04-23', 'Unclaimed', 'malabe', 'abcde@gmail.com'),
(2, 'phone', 'nokia', '2023-03-12', 'Unclaimed', 'piliyandala', 'chmod@gmail.com'),
(3, 'pen', 'atles', '2023-01-02', 'Unclaimed', 'pittugala', 'muthu@gmail.com'),
(4, 'book', 'novel', '2023-02-28', 'Unclaimed', 'kaduwela', 'chami@gmail.com'),
(11, 'Car', 'Civic', '2024-09-08', 'Claimed', 'Colombo', 'abc12@gmail.com'),
(12, 'phone', 'samsung', '2023-12-04', 'Claimed', 'Galle', 'surandidm@gmail.com'),
(13, 'laptop', 'lenovo ', '2024-05-05', 'Unclaimed', 'galle', 'nawodya124@gmail.com'),
(14, 'vehical', 'civic', '2024-03-04', 'Unclaimed', 'malabe', 'abc2gmail.com'),
(15, 'vehical', 'civic', '2024-01-02', 'Unclaimed', 'colombo', 'abc@gmail.com'),
(16, 'bag', 'black bag', '2024-02-05', 'Unclaimed', 'horana', 'def@gmail.com'),
(17, 'Car', 'CHR', '2023-10-12', 'Unclaimed', 'Colombo', 'Anu09@gmail.com'),
(18, 'vehicle', 'highbrid', '2023-12-04', 'Unclaimed', 'mathara', 'xyz@gmail.com'),
(19, 'phone', 'apple', '2023-12-04', 'Unclaimed', 'kegalle', 'ghi@gmail.com'),
(20, 'bag', 'white', '2022-12-12', 'Unclaimed', 'anuradhapura', 'sri@gmail.com'),
(21, 'car', 'white car', '2024-06-07', 'Unclaimed', 'panadura', 'abcd@gmail.com'),
(22, 'phone', 'a03s samsung', '2023-04-10', 'Unclaimed', 'kiriella', 'rash123@gmail.com'),
(23, 'bag', 'red', '2023-06-05', 'Unclaimed', 'kuruwita', 'asdgmail.com'),
(24, 'phone', 'oppo', '2022-12-04', 'Unclaimed', 'galle', 'abxcf@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User Id` int(10) NOT NULL,
  `User Name` varchar(50) NOT NULL,
  `User Level` varchar(10) NOT NULL,
  `Password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User Id`, `User Name`, `User Level`, `Password`) VALUES
(1, '12', 'Admin', '12'),
(2, 'surandi', 'Losser', 'chmod123'),
(5, 'anu', 'Founder', 'anu123'),
(6, 'neth', 'Founder', '1234'),
(13, 'nethmi', 'Losser', 'neth12'),
(16, 'ishara', 'Founder', 'ishuneth'),
(17, 'Anuradha', 'Admin', 'ABC123'),
(18, 'kalhara', 'Founder', 'kl123'),
(19, 'saduni', 'Losser', 'sadu123'),
(20, 'nawodya', 'Admin', 'nawo12'),
(21, 'anuradha', 'Admin', 'anu123'),
(22, 'naduni', 'Losser', 'nadu12'),
(23, 'mala', 'Founder', 'mala12'),
(24, 'malshi', 'Founder', 'mal12'),
(25, 'Anne', 'Founder', 'A123'),
(26, 'tharu', 'Founder', 'tharu12'),
(27, 'nethmi', 'Founder', 'neth123'),
(28, 'mala', 'Founder', 'mala12'),
(29, 'nawodya', 'Founder', 'nawo123'),
(30, 'saman', 'Founder', 'saman12'),
(31, 'amal', 'Founder', 'amal123'),
(32, 'tharushi', 'Founder', 'tharu12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`Item Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `Item Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
